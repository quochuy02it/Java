public class StudentManagement {
    private
    Student[] Students;

    public StudentManagement() {
        Students = new Student[100];
    }

    public int getSize() {
        int size = 0;
        for (int i = 0; i<this.Students.length; i++) {
            if(this.Students[i] != null) {
                size++;
            } else {
                break;
            }
        }
        return size;
    }

    public void addStudent(Student newStudent) {
        int size = this.getSize();
        for(int i = 0; i < size; i++) {
            if(this.Students[i].getId() == newStudent.getId()) {
                return;
            }
        }
        this.Students[this.getSize()] = newStudent;
    }

    public String studentsByGroup() {
        String result = "";
        int sizeStudent = this.getSize();
        int sizeClass = 0;
        String[] className = new String[sizeStudent];
        for (int i = 0; i < sizeStudent; i++) {
            boolean checkExist = false;
            for (int j = 0; j < sizeClass; j++) {
                if (this.Students[i].getGroup() == className[j]) {
                    checkExist = true;
                    break;
                }
            }
            if (!checkExist) {
                className[sizeClass] = this.Students[i].getGroup();
                sizeClass++;
            }
        }

        for (int i = 0; i < sizeClass; i++) {
            result += className[i] + '\n';
            for (int j = 0; j < sizeStudent; j++) {
                if (this.Students[j].getGroup() == className[i]) {
                    result += this.Students[j].getInfo() + '\n';
                }
            }
        }
        return result;
    }

    public void removeStudent(String id) {
        int currentIndex = 0;
        int oldSize = this.getSize();
        for(int i = 0; i < oldSize; i++) {
            this.Students[currentIndex] = this.Students[i];
            if(this.Students[i].getId() != id) {
                currentIndex++;
            }
        }
        for (int i = currentIndex; i < oldSize; i++) {
            this.Students[i] = null;
        }

    }

    public static boolean sameGroup(Student s1, Student s2) {
        return s1.getGroup() == s2.getGroup();
    }

    public static void main(String[] args) {
        StudentManagement test = new StudentManagement();
        //id is unique
        Student Student1 = new Student("huy", "123", "roger@gmail.com");
        Student Student2 = new Student("huy", "1234", "rogergold@gmail.com");
        Student Student3 = new Student("huy", "12345", "abc@gmail.com");
        Student Student4 = new Student("huyyy", "1", "123d@gmail.com");
        Student2.setGroup("k65j");
        test.addStudent(Student1);
        test.addStudent(Student2);
        test.addStudent(Student3);
        test.addStudent((Student4));
        test.removeStudent("1");
        System.out.println(test.studentsByGroup());
    }
}
